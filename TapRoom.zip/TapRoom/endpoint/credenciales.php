<?php
// credenciales.php

$host = "198.12.247.139";
$usuario = "DuckAdminTapRoom";
$contrasena = "TapRoom2024";
$nombreBaseDatos = "TapRoom";
?>
