<?php
// Habilitar visualización de errores y advertencias
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar si la extensión mysqli está habilitada
if (!extension_loaded("mysqli")) {
    die("La extensión mysqli no está habilitada. Por favor, verifica tu configuración de PHP.");
}

// Configuración de la conexión a la base de datos
$host = "198.12.247.139"; // o la dirección IP del servidor de bases de datos si es diferente
$usuario = "DuckAdminTapRoom"; // tu nombre de usuario de la base de datos
$contrasena = "TapRoom2024"; // tu contraseña de la base de datos
$nombreBaseDatos = "TapRoom"; // el nombre de tu base de datos

// Intentar conexión
$conexion = new mysqli($host, $usuario, $contrasena, $nombreBaseDatos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Establecer el conjunto de caracteres a utf8 para manejar correctamente caracteres latinos y acentos
if (!$conexion->set_charset("utf8")) {
    printf("Error cargando el conjunto de caracteres utf8: %s\n", $conexion->error);
    exit();
}

// Establecer el tipo de contenido de la respuesta a JSON
header('Content-Type: application/json');

// La consulta a la base de datos
$consulta = "SELECT * FROM TapRoom.Cervezas";

// Ejecutar consulta
$resultado = $conexion->query($consulta);

// Verificar si la consulta se realizó correctamente
if ($resultado) {
    // Crear un array para almacenar los resultados
    $datos = array();
    
    // Recuperar los resultados y almacenarlos en el array
    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }
    
    // Convertir el array de resultados en JSON y enviarlo
    echo json_encode($datos, JSON_UNESCAPED_UNICODE); // Asegura que los caracteres especiales se codifiquen correctamente en JSON
} else {
    // Mostrar error en caso de fallo en la consulta
    echo json_encode(["error" => "Error en la consulta: " . $conexion->error], JSON_UNESCAPED_UNICODE);
}

// Cerrar conexión
$conexion->close();
?>
